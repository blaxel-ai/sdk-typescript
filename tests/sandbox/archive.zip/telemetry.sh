BL_DEBUG_TELEMETRY="false" \
BL_SERVER_PORT="1338" \
BL_ENABLE_OPENTELEMETRY="true" \
BL_WORKSPACE="main" \
BL_TYPE="agent" \
BL_NAME="agent-telemetry" \
OTEL_TRACES_EXPORTER="otlp" \
OTEL_METRICS_EXPORTER="otlp" \
OTEL_LOGS_EXPORTER="otlp" \
OTEL_BLRP_EXPORT_TIMEOUT="1" \
OTEL_EXPORTER_OTLP_ENDPOINT="https://otlp.blaxel.ai" \
OTEL_EXPORTER_OTLP_PROTOCOL="http/protobuf" \
OTEL_TRACES_SAMPLER="parentbased_traceidratio" \
OTEL_TRACES_SAMPLER_ARG="1" \
OTEL_RESOURCE_ATTRIBUTES="workload.id=agent-telemetry,workspace=main,workload.type=agents,service.group=executionplane,service.domain=execution" \
BL_CLIENT_CREDENTIALS="bWFpbjpQUlUyRkI4WU1DSjhETEE2R0pMV1YzV0xRWE1PUUlEMQ==" \
LOG_LEVEL=INFO \
tsx --watch tests/fastify_langchain.ts
